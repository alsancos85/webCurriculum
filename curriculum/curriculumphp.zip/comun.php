<?php

$nav_bar='<ul class="nav">
				<li><a href="llamada2.php">Sobre mí</a></li>
				<li><a href="">Estudios y habilidades </a>
						
						</li>
						
				
				<li><a href="">Experiencia</a>
				
				</li>
				<li><a href="">Configuracion</a>
					<ul>
						<li><a href="config.php">Cambiar datos</a></li>
						<li><a href="">Crear nuevo perfil</a></li>
						<li><a href="">Cerrar sesión</a></li>

					</ul>
				</li>
			</ul>


';

?>